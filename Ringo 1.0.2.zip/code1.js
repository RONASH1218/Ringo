gdjs.Level1Code = {};
gdjs.Level1Code.forEachCount0_3 = 0;

gdjs.Level1Code.forEachCount1_3 = 0;

gdjs.Level1Code.forEachCount2_3 = 0;

gdjs.Level1Code.forEachCount3_3 = 0;

gdjs.Level1Code.forEachIndex2 = 0;

gdjs.Level1Code.forEachIndex3 = 0;

gdjs.Level1Code.forEachObjects2 = [];

gdjs.Level1Code.forEachObjects3 = [];

gdjs.Level1Code.forEachTemporary2 = null;

gdjs.Level1Code.forEachTotalCount2 = 0;

gdjs.Level1Code.forEachTotalCount3 = 0;

gdjs.Level1Code.GDScoreObjects1= [];
gdjs.Level1Code.GDScoreObjects2= [];
gdjs.Level1Code.GDScoreObjects3= [];
gdjs.Level1Code.GDScoreObjects4= [];
gdjs.Level1Code.GDScoreObjects5= [];
gdjs.Level1Code.GDLifeObjects1= [];
gdjs.Level1Code.GDLifeObjects2= [];
gdjs.Level1Code.GDLifeObjects3= [];
gdjs.Level1Code.GDLifeObjects4= [];
gdjs.Level1Code.GDLifeObjects5= [];
gdjs.Level1Code.GDShape2Objects1= [];
gdjs.Level1Code.GDShape2Objects2= [];
gdjs.Level1Code.GDShape2Objects3= [];
gdjs.Level1Code.GDShape2Objects4= [];
gdjs.Level1Code.GDShape2Objects5= [];
gdjs.Level1Code.GDShape1Objects1= [];
gdjs.Level1Code.GDShape1Objects2= [];
gdjs.Level1Code.GDShape1Objects3= [];
gdjs.Level1Code.GDShape1Objects4= [];
gdjs.Level1Code.GDShape1Objects5= [];
gdjs.Level1Code.GDShape3Objects1= [];
gdjs.Level1Code.GDShape3Objects2= [];
gdjs.Level1Code.GDShape3Objects3= [];
gdjs.Level1Code.GDShape3Objects4= [];
gdjs.Level1Code.GDShape3Objects5= [];
gdjs.Level1Code.GDShape4Objects1= [];
gdjs.Level1Code.GDShape4Objects2= [];
gdjs.Level1Code.GDShape4Objects3= [];
gdjs.Level1Code.GDShape4Objects4= [];
gdjs.Level1Code.GDShape4Objects5= [];
gdjs.Level1Code.GDShape1ExplosionObjects1= [];
gdjs.Level1Code.GDShape1ExplosionObjects2= [];
gdjs.Level1Code.GDShape1ExplosionObjects3= [];
gdjs.Level1Code.GDShape1ExplosionObjects4= [];
gdjs.Level1Code.GDShape1ExplosionObjects5= [];
gdjs.Level1Code.GDShape2ExplosionObjects1= [];
gdjs.Level1Code.GDShape2ExplosionObjects2= [];
gdjs.Level1Code.GDShape2ExplosionObjects3= [];
gdjs.Level1Code.GDShape2ExplosionObjects4= [];
gdjs.Level1Code.GDShape2ExplosionObjects5= [];
gdjs.Level1Code.GDShape3ExplosionObjects1= [];
gdjs.Level1Code.GDShape3ExplosionObjects2= [];
gdjs.Level1Code.GDShape3ExplosionObjects3= [];
gdjs.Level1Code.GDShape3ExplosionObjects4= [];
gdjs.Level1Code.GDShape3ExplosionObjects5= [];
gdjs.Level1Code.GDShape4ExplosionObjects1= [];
gdjs.Level1Code.GDShape4ExplosionObjects2= [];
gdjs.Level1Code.GDShape4ExplosionObjects3= [];
gdjs.Level1Code.GDShape4ExplosionObjects4= [];
gdjs.Level1Code.GDShape4ExplosionObjects5= [];
gdjs.Level1Code.GDObstacleObjects1= [];
gdjs.Level1Code.GDObstacleObjects2= [];
gdjs.Level1Code.GDObstacleObjects3= [];
gdjs.Level1Code.GDObstacleObjects4= [];
gdjs.Level1Code.GDObstacleObjects5= [];
gdjs.Level1Code.GDCatObjects1= [];
gdjs.Level1Code.GDCatObjects2= [];
gdjs.Level1Code.GDCatObjects3= [];
gdjs.Level1Code.GDCatObjects4= [];
gdjs.Level1Code.GDCatObjects5= [];
gdjs.Level1Code.GDDogObjects1= [];
gdjs.Level1Code.GDDogObjects2= [];
gdjs.Level1Code.GDDogObjects3= [];
gdjs.Level1Code.GDDogObjects4= [];
gdjs.Level1Code.GDDogObjects5= [];
gdjs.Level1Code.GDRobotObjects1= [];
gdjs.Level1Code.GDRobotObjects2= [];
gdjs.Level1Code.GDRobotObjects3= [];
gdjs.Level1Code.GDRobotObjects4= [];
gdjs.Level1Code.GDRobotObjects5= [];
gdjs.Level1Code.GDKnightObjects1= [];
gdjs.Level1Code.GDKnightObjects2= [];
gdjs.Level1Code.GDKnightObjects3= [];
gdjs.Level1Code.GDKnightObjects4= [];
gdjs.Level1Code.GDKnightObjects5= [];
gdjs.Level1Code.GDAdventureGirlObjects1= [];
gdjs.Level1Code.GDAdventureGirlObjects2= [];
gdjs.Level1Code.GDAdventureGirlObjects3= [];
gdjs.Level1Code.GDAdventureGirlObjects4= [];
gdjs.Level1Code.GDAdventureGirlObjects5= [];
gdjs.Level1Code.GDZombieBoyObjects1= [];
gdjs.Level1Code.GDZombieBoyObjects2= [];
gdjs.Level1Code.GDZombieBoyObjects3= [];
gdjs.Level1Code.GDZombieBoyObjects4= [];
gdjs.Level1Code.GDZombieBoyObjects5= [];
gdjs.Level1Code.GDNinjaGirlObjects1= [];
gdjs.Level1Code.GDNinjaGirlObjects2= [];
gdjs.Level1Code.GDNinjaGirlObjects3= [];
gdjs.Level1Code.GDNinjaGirlObjects4= [];
gdjs.Level1Code.GDNinjaGirlObjects5= [];
gdjs.Level1Code.GDNinjaBoyObjects1= [];
gdjs.Level1Code.GDNinjaBoyObjects2= [];
gdjs.Level1Code.GDNinjaBoyObjects3= [];
gdjs.Level1Code.GDNinjaBoyObjects4= [];
gdjs.Level1Code.GDNinjaBoyObjects5= [];
gdjs.Level1Code.GDAdventureBoyObjects1= [];
gdjs.Level1Code.GDAdventureBoyObjects2= [];
gdjs.Level1Code.GDAdventureBoyObjects3= [];
gdjs.Level1Code.GDAdventureBoyObjects4= [];
gdjs.Level1Code.GDAdventureBoyObjects5= [];
gdjs.Level1Code.GDZombieGirlObjects1= [];
gdjs.Level1Code.GDZombieGirlObjects2= [];
gdjs.Level1Code.GDZombieGirlObjects3= [];
gdjs.Level1Code.GDZombieGirlObjects4= [];
gdjs.Level1Code.GDZombieGirlObjects5= [];


gdjs.Level1Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 6;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 7;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 8;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 9;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level1Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDCatObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDCatObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDCatObjects2[k] = gdjs.Level1Code.GDCatObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDCatObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDogObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDDogObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDDogObjects2[k] = gdjs.Level1Code.GDDogObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDDogObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDKnightObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDKnightObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDKnightObjects2[k] = gdjs.Level1Code.GDKnightObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDKnightObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDRobotObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDRobotObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDRobotObjects2[k] = gdjs.Level1Code.GDRobotObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDRobotObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureBoyObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDAdventureBoyObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureBoyObjects2[k] = gdjs.Level1Code.GDAdventureBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaBoyObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDNinjaBoyObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaBoyObjects2[k] = gdjs.Level1Code.GDNinjaBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaGirlObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDNinjaGirlObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaGirlObjects2[k] = gdjs.Level1Code.GDNinjaGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaGirlObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieBoyObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDZombieBoyObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieBoyObjects2[k] = gdjs.Level1Code.GDZombieBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureGirlObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDAdventureGirlObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureGirlObjects2[k] = gdjs.Level1Code.GDAdventureGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureGirlObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieGirlObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDZombieGirlObjects2[i].getCenterXInScene() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) + 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieGirlObjects2[k] = gdjs.Level1Code.GDZombieGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieGirlObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDAdventureBoyObjects2 */
/* Reuse gdjs.Level1Code.GDAdventureGirlObjects2 */
/* Reuse gdjs.Level1Code.GDCatObjects2 */
/* Reuse gdjs.Level1Code.GDDogObjects2 */
/* Reuse gdjs.Level1Code.GDKnightObjects2 */
/* Reuse gdjs.Level1Code.GDNinjaBoyObjects2 */
/* Reuse gdjs.Level1Code.GDNinjaGirlObjects2 */
/* Reuse gdjs.Level1Code.GDRobotObjects2 */
/* Reuse gdjs.Level1Code.GDZombieBoyObjects2 */
/* Reuse gdjs.Level1Code.GDZombieGirlObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects1);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDCatObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDCatObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDCatObjects1[k] = gdjs.Level1Code.GDCatObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDCatObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDogObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDDogObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDDogObjects1[k] = gdjs.Level1Code.GDDogObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDDogObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDKnightObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDKnightObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDKnightObjects1[k] = gdjs.Level1Code.GDKnightObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDKnightObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDRobotObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDRobotObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDRobotObjects1[k] = gdjs.Level1Code.GDRobotObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDRobotObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureBoyObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDAdventureBoyObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureBoyObjects1[k] = gdjs.Level1Code.GDAdventureBoyObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureBoyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaBoyObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDNinjaBoyObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaBoyObjects1[k] = gdjs.Level1Code.GDNinjaBoyObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaBoyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaGirlObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDNinjaGirlObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaGirlObjects1[k] = gdjs.Level1Code.GDNinjaGirlObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaGirlObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieBoyObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDZombieBoyObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieBoyObjects1[k] = gdjs.Level1Code.GDZombieBoyObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieBoyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureGirlObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDAdventureGirlObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureGirlObjects1[k] = gdjs.Level1Code.GDAdventureGirlObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureGirlObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieGirlObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDZombieGirlObjects1[i].getCenterXInScene() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 5 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieGirlObjects1[k] = gdjs.Level1Code.GDZombieGirlObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieGirlObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDAdventureBoyObjects1 */
/* Reuse gdjs.Level1Code.GDAdventureGirlObjects1 */
/* Reuse gdjs.Level1Code.GDCatObjects1 */
/* Reuse gdjs.Level1Code.GDDogObjects1 */
/* Reuse gdjs.Level1Code.GDKnightObjects1 */
/* Reuse gdjs.Level1Code.GDNinjaBoyObjects1 */
/* Reuse gdjs.Level1Code.GDNinjaGirlObjects1 */
/* Reuse gdjs.Level1Code.GDRobotObjects1 */
/* Reuse gdjs.Level1Code.GDZombieBoyObjects1 */
/* Reuse gdjs.Level1Code.GDZombieGirlObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDCatObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDDogObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDKnightObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDRobotObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects1[i].getBehavior("TopDownMovement").simulateRightKey();
}
}}

}


};gdjs.Level1Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape1Objects2ObjectsGDgdjs_9546Level1Code_9546GDShape2Objects2ObjectsGDgdjs_9546Level1Code_9546GDShape3Objects2ObjectsGDgdjs_9546Level1Code_9546GDShape4Objects2Objects = Hashtable.newFrom({"Shape1": gdjs.Level1Code.GDShape1Objects2, "Shape2": gdjs.Level1Code.GDShape2Objects2, "Shape3": gdjs.Level1Code.GDShape3Objects2, "Shape4": gdjs.Level1Code.GDShape4Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDObstacleObjects1Objects = Hashtable.newFrom({"Obstacle": gdjs.Level1Code.GDObstacleObjects1});
gdjs.Level1Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ShapeCreation");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ShapeCreation") > 1.3;
if (isConditionTrue_0) {
gdjs.Level1Code.GDShape1Objects2.length = 0;

gdjs.Level1Code.GDShape2Objects2.length = 0;

gdjs.Level1Code.GDShape3Objects2.length = 0;

gdjs.Level1Code.GDShape4Objects2.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape1Objects2ObjectsGDgdjs_9546Level1Code_9546GDShape2Objects2ObjectsGDgdjs_9546Level1Code_9546GDShape3Objects2ObjectsGDgdjs_9546Level1Code_9546GDShape4Objects2Objects, "Shape" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 4)), gdjs.randomInRange(80, 1080 - 80), -(120), "");
}{for(var i = 0, len = gdjs.Level1Code.GDShape1Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape1Objects2[i].setScale(gdjs.randomFloatInRange(1.4, 1.8));
}
for(var i = 0, len = gdjs.Level1Code.GDShape2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape2Objects2[i].setScale(gdjs.randomFloatInRange(1.4, 1.8));
}
for(var i = 0, len = gdjs.Level1Code.GDShape3Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape3Objects2[i].setScale(gdjs.randomFloatInRange(1.4, 1.8));
}
for(var i = 0, len = gdjs.Level1Code.GDShape4Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape4Objects2[i].setScale(gdjs.randomFloatInRange(1.4, 1.8));
}
}{for(var i = 0, len = gdjs.Level1Code.GDShape1Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape1Objects2[i].setAngle(gdjs.randomInRange(0, 360));
}
for(var i = 0, len = gdjs.Level1Code.GDShape2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape2Objects2[i].setAngle(gdjs.randomInRange(0, 360));
}
for(var i = 0, len = gdjs.Level1Code.GDShape3Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape3Objects2[i].setAngle(gdjs.randomInRange(0, 360));
}
for(var i = 0, len = gdjs.Level1Code.GDShape4Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape4Objects2[i].setAngle(gdjs.randomInRange(0, 360));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ShapeCreation");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ObstacleCreation");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ObstacleCreation") > 5;
if (isConditionTrue_0) {
gdjs.Level1Code.GDObstacleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDObstacleObjects1Objects, gdjs.randomInRange(80, 1080 - 80), -(100), "");
}{for(var i = 0, len = gdjs.Level1Code.GDObstacleObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDObstacleObjects1[i].setScale(1.6);
}
}{for(var i = 0, len = gdjs.Level1Code.GDObstacleObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDObstacleObjects1[i].setZOrder(4);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ObstacleCreation");
}}

}


};gdjs.Level1Code.eventsList4 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level1Code.GDShape1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level1Code.GDShape2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level1Code.GDShape3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level1Code.GDShape4Objects2);
{for(var i = 0, len = gdjs.Level1Code.GDShape1Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape1Objects2[i].addForce(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level1Code.GDShape2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape2Objects2[i].addForce(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level1Code.GDShape3Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape3Objects2[i].addForce(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
for(var i = 0, len = gdjs.Level1Code.GDShape4Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape4Objects2[i].addForce(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
}{for(var i = 0, len = gdjs.Level1Code.GDShape1Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape1Objects2[i].rotate(90, runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDShape2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape2Objects2[i].rotate(90, runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDShape3Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape3Objects2[i].rotate(90, runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDShape4Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShape4Objects2[i].rotate(90, runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level1Code.GDObstacleObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDObstacleObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDObstacleObjects2[i].addPolarForce(90, 1.5 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(0).add(7 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape1Objects3ObjectsGDgdjs_9546Level1Code_9546GDShape2Objects3ObjectsGDgdjs_9546Level1Code_9546GDShape3Objects3ObjectsGDgdjs_9546Level1Code_9546GDShape4Objects3Objects = Hashtable.newFrom({"Shape1": gdjs.Level1Code.GDShape1Objects3, "Shape2": gdjs.Level1Code.GDShape2Objects3, "Shape3": gdjs.Level1Code.GDShape3Objects3, "Shape4": gdjs.Level1Code.GDShape4Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCatObjects3ObjectsGDgdjs_9546Level1Code_9546GDDogObjects3ObjectsGDgdjs_9546Level1Code_9546GDKnightObjects3ObjectsGDgdjs_9546Level1Code_9546GDRobotObjects3ObjectsGDgdjs_9546Level1Code_9546GDAdventureBoyObjects3ObjectsGDgdjs_9546Level1Code_9546GDNinjaBoyObjects3ObjectsGDgdjs_9546Level1Code_9546GDNinjaGirlObjects3ObjectsGDgdjs_9546Level1Code_9546GDZombieBoyObjects3ObjectsGDgdjs_9546Level1Code_9546GDAdventureGirlObjects3ObjectsGDgdjs_9546Level1Code_9546GDZombieGirlObjects3Objects = Hashtable.newFrom({"Cat": gdjs.Level1Code.GDCatObjects3, "Dog": gdjs.Level1Code.GDDogObjects3, "Knight": gdjs.Level1Code.GDKnightObjects3, "Robot": gdjs.Level1Code.GDRobotObjects3, "AdventureBoy": gdjs.Level1Code.GDAdventureBoyObjects3, "NinjaBoy": gdjs.Level1Code.GDNinjaBoyObjects3, "NinjaGirl": gdjs.Level1Code.GDNinjaGirlObjects3, "ZombieBoy": gdjs.Level1Code.GDZombieBoyObjects3, "AdventureGirl": gdjs.Level1Code.GDAdventureGirlObjects3, "ZombieGirl": gdjs.Level1Code.GDZombieGirlObjects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape1Objects3Objects = Hashtable.newFrom({"Shape1": gdjs.Level1Code.GDShape1Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape1ExplosionObjects4Objects = Hashtable.newFrom({"Shape1Explosion": gdjs.Level1Code.GDShape1ExplosionObjects4});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape2Objects3Objects = Hashtable.newFrom({"Shape2": gdjs.Level1Code.GDShape2Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape2ExplosionObjects4Objects = Hashtable.newFrom({"Shape2Explosion": gdjs.Level1Code.GDShape2ExplosionObjects4});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape3Objects3Objects = Hashtable.newFrom({"Shape3": gdjs.Level1Code.GDShape3Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape3ExplosionObjects4Objects = Hashtable.newFrom({"Shape3Explosion": gdjs.Level1Code.GDShape3ExplosionObjects4});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape4Objects3Objects = Hashtable.newFrom({"Shape4": gdjs.Level1Code.GDShape4Objects3});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape4ExplosionObjects4Objects = Hashtable.newFrom({"Shape4Explosion": gdjs.Level1Code.GDShape4ExplosionObjects4});
gdjs.Level1Code.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape1Objects3Objects) != 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDShape1Objects3, gdjs.Level1Code.GDShape1Objects4);

gdjs.Level1Code.GDShape1ExplosionObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape1ExplosionObjects4Objects, (( gdjs.Level1Code.GDShape1Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape1Objects4[0].getCenterXInScene()), (( gdjs.Level1Code.GDShape1Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape1Objects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Level1Code.GDShape1ExplosionObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDShape1ExplosionObjects4[i].setParticleSize1((( gdjs.Level1Code.GDShape1Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape1Objects4[0].getWidth()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape2Objects3Objects) != 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDShape2Objects3, gdjs.Level1Code.GDShape2Objects4);

gdjs.Level1Code.GDShape2ExplosionObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape2ExplosionObjects4Objects, (( gdjs.Level1Code.GDShape2Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape2Objects4[0].getCenterXInScene()), (( gdjs.Level1Code.GDShape2Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape2Objects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Level1Code.GDShape2ExplosionObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDShape2ExplosionObjects4[i].setParticleSize1((( gdjs.Level1Code.GDShape2Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape2Objects4[0].getWidth()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape3Objects3Objects) != 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDShape3Objects3, gdjs.Level1Code.GDShape3Objects4);

gdjs.Level1Code.GDShape3ExplosionObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape3ExplosionObjects4Objects, (( gdjs.Level1Code.GDShape3Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape3Objects4[0].getCenterXInScene()), (( gdjs.Level1Code.GDShape3Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape3Objects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Level1Code.GDShape3ExplosionObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDShape3ExplosionObjects4[i].setParticleSize1((( gdjs.Level1Code.GDShape3Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape3Objects4[0].getWidth()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape4Objects3Objects) != 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDShape4Objects3, gdjs.Level1Code.GDShape4Objects4);

gdjs.Level1Code.GDShape4ExplosionObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape4ExplosionObjects4Objects, (( gdjs.Level1Code.GDShape4Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape4Objects4[0].getCenterXInScene()), (( gdjs.Level1Code.GDShape4Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape4Objects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Level1Code.GDShape4ExplosionObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDShape4ExplosionObjects4[i].setParticleSize1((( gdjs.Level1Code.GDShape4Objects4.length === 0 ) ? 0 :gdjs.Level1Code.GDShape4Objects4[0].getWidth()));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level1Code.GDScoreObjects4);
gdjs.copyArray(gdjs.Level1Code.GDShape1Objects3, gdjs.Level1Code.GDShape1Objects4);

gdjs.copyArray(gdjs.Level1Code.GDShape2Objects3, gdjs.Level1Code.GDShape2Objects4);

gdjs.copyArray(gdjs.Level1Code.GDShape3Objects3, gdjs.Level1Code.GDShape3Objects4);

gdjs.copyArray(gdjs.Level1Code.GDShape4Objects3, gdjs.Level1Code.GDShape4Objects4);

{for(var i = 0, len = gdjs.Level1Code.GDShape1Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDShape1Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDShape2Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDShape2Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDShape3Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDShape3Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDShape4Objects4.length ;i < len;++i) {
    gdjs.Level1Code.GDShape4Objects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "power-up-sparkle-1-177983.mp3", false, 10, 1);
}{runtimeScene.getGame().getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.Level1Code.GDScoreObjects4.length ;i < len;++i) {
    gdjs.Level1Code.GDScoreObjects4[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Score"))));
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDObstacleObjects2Objects = Hashtable.newFrom({"Obstacle": gdjs.Level1Code.GDObstacleObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCatObjects2ObjectsGDgdjs_9546Level1Code_9546GDDogObjects2ObjectsGDgdjs_9546Level1Code_9546GDKnightObjects2ObjectsGDgdjs_9546Level1Code_9546GDRobotObjects2ObjectsGDgdjs_9546Level1Code_9546GDAdventureBoyObjects2ObjectsGDgdjs_9546Level1Code_9546GDNinjaBoyObjects2ObjectsGDgdjs_9546Level1Code_9546GDNinjaGirlObjects2ObjectsGDgdjs_9546Level1Code_9546GDZombieBoyObjects2ObjectsGDgdjs_9546Level1Code_9546GDAdventureGirlObjects2ObjectsGDgdjs_9546Level1Code_9546GDZombieGirlObjects2Objects = Hashtable.newFrom({"Cat": gdjs.Level1Code.GDCatObjects2, "Dog": gdjs.Level1Code.GDDogObjects2, "Knight": gdjs.Level1Code.GDKnightObjects2, "Robot": gdjs.Level1Code.GDRobotObjects2, "AdventureBoy": gdjs.Level1Code.GDAdventureBoyObjects2, "NinjaBoy": gdjs.Level1Code.GDNinjaBoyObjects2, "NinjaGirl": gdjs.Level1Code.GDNinjaGirlObjects2, "ZombieBoy": gdjs.Level1Code.GDZombieBoyObjects2, "AdventureGirl": gdjs.Level1Code.GDAdventureGirlObjects2, "ZombieGirl": gdjs.Level1Code.GDZombieGirlObjects2});
gdjs.Level1Code.asyncCallback14549268 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Level1Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level1Code.asyncCallback14549268(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Shape1"), gdjs.Level1Code.GDShape1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shape2"), gdjs.Level1Code.GDShape2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shape3"), gdjs.Level1Code.GDShape3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Shape4"), gdjs.Level1Code.GDShape4Objects2);

gdjs.Level1Code.forEachTotalCount3 = 0;
gdjs.Level1Code.forEachObjects3.length = 0;
gdjs.Level1Code.forEachCount0_3 = gdjs.Level1Code.GDShape1Objects2.length;
gdjs.Level1Code.forEachTotalCount3 += gdjs.Level1Code.forEachCount0_3;
gdjs.Level1Code.forEachObjects3.push.apply(gdjs.Level1Code.forEachObjects3,gdjs.Level1Code.GDShape1Objects2);
gdjs.Level1Code.forEachCount1_3 = gdjs.Level1Code.GDShape2Objects2.length;
gdjs.Level1Code.forEachTotalCount3 += gdjs.Level1Code.forEachCount1_3;
gdjs.Level1Code.forEachObjects3.push.apply(gdjs.Level1Code.forEachObjects3,gdjs.Level1Code.GDShape2Objects2);
gdjs.Level1Code.forEachCount2_3 = gdjs.Level1Code.GDShape3Objects2.length;
gdjs.Level1Code.forEachTotalCount3 += gdjs.Level1Code.forEachCount2_3;
gdjs.Level1Code.forEachObjects3.push.apply(gdjs.Level1Code.forEachObjects3,gdjs.Level1Code.GDShape3Objects2);
gdjs.Level1Code.forEachCount3_3 = gdjs.Level1Code.GDShape4Objects2.length;
gdjs.Level1Code.forEachTotalCount3 += gdjs.Level1Code.forEachCount3_3;
gdjs.Level1Code.forEachObjects3.push.apply(gdjs.Level1Code.forEachObjects3,gdjs.Level1Code.GDShape4Objects2);
for (gdjs.Level1Code.forEachIndex3 = 0;gdjs.Level1Code.forEachIndex3 < gdjs.Level1Code.forEachTotalCount3;++gdjs.Level1Code.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects3);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects3);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects3);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects3);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects3);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects3);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects3);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects3);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects3);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects3);
gdjs.Level1Code.GDShape1Objects3.length = 0;

gdjs.Level1Code.GDShape2Objects3.length = 0;

gdjs.Level1Code.GDShape3Objects3.length = 0;

gdjs.Level1Code.GDShape4Objects3.length = 0;


if (gdjs.Level1Code.forEachIndex3 < gdjs.Level1Code.forEachCount0_3) {
    gdjs.Level1Code.GDShape1Objects3.push(gdjs.Level1Code.forEachObjects3[gdjs.Level1Code.forEachIndex3]);
}
else if (gdjs.Level1Code.forEachIndex3 < gdjs.Level1Code.forEachCount0_3+gdjs.Level1Code.forEachCount1_3) {
    gdjs.Level1Code.GDShape2Objects3.push(gdjs.Level1Code.forEachObjects3[gdjs.Level1Code.forEachIndex3]);
}
else if (gdjs.Level1Code.forEachIndex3 < gdjs.Level1Code.forEachCount0_3+gdjs.Level1Code.forEachCount1_3+gdjs.Level1Code.forEachCount2_3) {
    gdjs.Level1Code.GDShape3Objects3.push(gdjs.Level1Code.forEachObjects3[gdjs.Level1Code.forEachIndex3]);
}
else if (gdjs.Level1Code.forEachIndex3 < gdjs.Level1Code.forEachCount0_3+gdjs.Level1Code.forEachCount1_3+gdjs.Level1Code.forEachCount2_3+gdjs.Level1Code.forEachCount3_3) {
    gdjs.Level1Code.GDShape4Objects3.push(gdjs.Level1Code.forEachObjects3[gdjs.Level1Code.forEachIndex3]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDShape1Objects3ObjectsGDgdjs_9546Level1Code_9546GDShape2Objects3ObjectsGDgdjs_9546Level1Code_9546GDShape3Objects3ObjectsGDgdjs_9546Level1Code_9546GDShape4Objects3Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCatObjects3ObjectsGDgdjs_9546Level1Code_9546GDDogObjects3ObjectsGDgdjs_9546Level1Code_9546GDKnightObjects3ObjectsGDgdjs_9546Level1Code_9546GDRobotObjects3ObjectsGDgdjs_9546Level1Code_9546GDAdventureBoyObjects3ObjectsGDgdjs_9546Level1Code_9546GDNinjaBoyObjects3ObjectsGDgdjs_9546Level1Code_9546GDNinjaGirlObjects3ObjectsGDgdjs_9546Level1Code_9546GDZombieBoyObjects3ObjectsGDgdjs_9546Level1Code_9546GDAdventureGirlObjects3ObjectsGDgdjs_9546Level1Code_9546GDZombieGirlObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.Level1Code.eventsList5(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Level1Code.GDObstacleObjects1);

for (gdjs.Level1Code.forEachIndex2 = 0;gdjs.Level1Code.forEachIndex2 < gdjs.Level1Code.GDObstacleObjects1.length;++gdjs.Level1Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);
gdjs.Level1Code.GDObstacleObjects2.length = 0;


gdjs.Level1Code.forEachTemporary2 = gdjs.Level1Code.GDObstacleObjects1[gdjs.Level1Code.forEachIndex2];
gdjs.Level1Code.GDObstacleObjects2.push(gdjs.Level1Code.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDObstacleObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDCatObjects2ObjectsGDgdjs_9546Level1Code_9546GDDogObjects2ObjectsGDgdjs_9546Level1Code_9546GDKnightObjects2ObjectsGDgdjs_9546Level1Code_9546GDRobotObjects2ObjectsGDgdjs_9546Level1Code_9546GDAdventureBoyObjects2ObjectsGDgdjs_9546Level1Code_9546GDNinjaBoyObjects2ObjectsGDgdjs_9546Level1Code_9546GDNinjaGirlObjects2ObjectsGDgdjs_9546Level1Code_9546GDZombieBoyObjects2ObjectsGDgdjs_9546Level1Code_9546GDAdventureGirlObjects2ObjectsGDgdjs_9546Level1Code_9546GDZombieGirlObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Level1Code.GDObstacleObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDObstacleObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "killed.wav", false, 10, 1);
}
{ //Subevents: 
gdjs.Level1Code.eventsList6(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Level1Code.eventsList8 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDAdventureBoyObjects2 */
/* Reuse gdjs.Level1Code.GDAdventureGirlObjects2 */
/* Reuse gdjs.Level1Code.GDCatObjects2 */
/* Reuse gdjs.Level1Code.GDDogObjects2 */
/* Reuse gdjs.Level1Code.GDKnightObjects2 */
/* Reuse gdjs.Level1Code.GDNinjaBoyObjects2 */
/* Reuse gdjs.Level1Code.GDNinjaGirlObjects2 */
/* Reuse gdjs.Level1Code.GDRobotObjects2 */
/* Reuse gdjs.Level1Code.GDZombieBoyObjects2 */
/* Reuse gdjs.Level1Code.GDZombieGirlObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDCatObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDCatObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDCatObjects2[k] = gdjs.Level1Code.GDCatObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDCatObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDogObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDDogObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDDogObjects2[k] = gdjs.Level1Code.GDDogObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDDogObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDKnightObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDKnightObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDKnightObjects2[k] = gdjs.Level1Code.GDKnightObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDKnightObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDRobotObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDRobotObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDRobotObjects2[k] = gdjs.Level1Code.GDRobotObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDRobotObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureBoyObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDAdventureBoyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureBoyObjects2[k] = gdjs.Level1Code.GDAdventureBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaBoyObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDNinjaBoyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaBoyObjects2[k] = gdjs.Level1Code.GDNinjaBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaGirlObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDNinjaGirlObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaGirlObjects2[k] = gdjs.Level1Code.GDNinjaGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaGirlObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieBoyObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDZombieBoyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieBoyObjects2[k] = gdjs.Level1Code.GDZombieBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureGirlObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDAdventureGirlObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureGirlObjects2[k] = gdjs.Level1Code.GDAdventureGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureGirlObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieGirlObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDZombieGirlObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieGirlObjects2[k] = gdjs.Level1Code.GDZombieGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieGirlObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDAdventureBoyObjects2 */
/* Reuse gdjs.Level1Code.GDAdventureGirlObjects2 */
/* Reuse gdjs.Level1Code.GDCatObjects2 */
/* Reuse gdjs.Level1Code.GDDogObjects2 */
/* Reuse gdjs.Level1Code.GDKnightObjects2 */
/* Reuse gdjs.Level1Code.GDNinjaBoyObjects2 */
/* Reuse gdjs.Level1Code.GDNinjaGirlObjects2 */
/* Reuse gdjs.Level1Code.GDRobotObjects2 */
/* Reuse gdjs.Level1Code.GDZombieBoyObjects2 */
/* Reuse gdjs.Level1Code.GDZombieGirlObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].getBehavior("Flash").Flash(1.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Level1Code.asyncCallback17608372 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);

{gdjs.adMob.hideBanner();
}{gdjs.adMob.hideBanner();
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.5);
}{gdjs.adMob.loadRewardedInterstitial("ca-app-pub-4492434867800612/5239848225", "", true);
}{for(var i = 0, len = gdjs.Level1Code.GDCatObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDDogObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDKnightObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDRobotObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}
gdjs.Level1Code.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level1Code.GDAdventureBoyObjects1) asyncObjectsList.addObject("AdventureBoy", obj);
for (const obj of gdjs.Level1Code.GDAdventureGirlObjects1) asyncObjectsList.addObject("AdventureGirl", obj);
for (const obj of gdjs.Level1Code.GDCatObjects1) asyncObjectsList.addObject("Cat", obj);
for (const obj of gdjs.Level1Code.GDDogObjects1) asyncObjectsList.addObject("Dog", obj);
for (const obj of gdjs.Level1Code.GDKnightObjects1) asyncObjectsList.addObject("Knight", obj);
for (const obj of gdjs.Level1Code.GDNinjaBoyObjects1) asyncObjectsList.addObject("NinjaBoy", obj);
for (const obj of gdjs.Level1Code.GDNinjaGirlObjects1) asyncObjectsList.addObject("NinjaGirl", obj);
for (const obj of gdjs.Level1Code.GDRobotObjects1) asyncObjectsList.addObject("Robot", obj);
for (const obj of gdjs.Level1Code.GDZombieBoyObjects1) asyncObjectsList.addObject("ZombieBoy", obj);
for (const obj of gdjs.Level1Code.GDZombieGirlObjects1) asyncObjectsList.addObject("ZombieGirl", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Level1Code.asyncCallback17608372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDCatObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDCatObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDCatObjects2[k] = gdjs.Level1Code.GDCatObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDCatObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDogObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDDogObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDDogObjects2[k] = gdjs.Level1Code.GDDogObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDDogObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDKnightObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDKnightObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDKnightObjects2[k] = gdjs.Level1Code.GDKnightObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDKnightObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDRobotObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDRobotObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDRobotObjects2[k] = gdjs.Level1Code.GDRobotObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDRobotObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureBoyObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDAdventureBoyObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureBoyObjects2[k] = gdjs.Level1Code.GDAdventureBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaBoyObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDNinjaBoyObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaBoyObjects2[k] = gdjs.Level1Code.GDNinjaBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaGirlObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDNinjaGirlObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaGirlObjects2[k] = gdjs.Level1Code.GDNinjaGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaGirlObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieBoyObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDZombieBoyObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieBoyObjects2[k] = gdjs.Level1Code.GDZombieBoyObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieBoyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureGirlObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDAdventureGirlObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureGirlObjects2[k] = gdjs.Level1Code.GDAdventureGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureGirlObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieGirlObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDZombieGirlObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieGirlObjects2[k] = gdjs.Level1Code.GDZombieGirlObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieGirlObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDAdventureBoyObjects2 */
/* Reuse gdjs.Level1Code.GDAdventureGirlObjects2 */
/* Reuse gdjs.Level1Code.GDCatObjects2 */
/* Reuse gdjs.Level1Code.GDDogObjects2 */
/* Reuse gdjs.Level1Code.GDKnightObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.Level1Code.GDLifeObjects2);
/* Reuse gdjs.Level1Code.GDNinjaBoyObjects2 */
/* Reuse gdjs.Level1Code.GDNinjaGirlObjects2 */
/* Reuse gdjs.Level1Code.GDRobotObjects2 */
/* Reuse gdjs.Level1Code.GDZombieBoyObjects2 */
/* Reuse gdjs.Level1Code.GDZombieGirlObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDLifeObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDLifeObjects2[i].SetValue((( gdjs.Level1Code.GDZombieGirlObjects2.length === 0 ) ? (( gdjs.Level1Code.GDAdventureGirlObjects2.length === 0 ) ? (( gdjs.Level1Code.GDZombieBoyObjects2.length === 0 ) ? (( gdjs.Level1Code.GDNinjaGirlObjects2.length === 0 ) ? (( gdjs.Level1Code.GDNinjaBoyObjects2.length === 0 ) ? (( gdjs.Level1Code.GDAdventureBoyObjects2.length === 0 ) ? (( gdjs.Level1Code.GDRobotObjects2.length === 0 ) ? (( gdjs.Level1Code.GDKnightObjects2.length === 0 ) ? (( gdjs.Level1Code.GDDogObjects2.length === 0 ) ? (( gdjs.Level1Code.GDCatObjects2.length === 0 ) ? 0 :gdjs.Level1Code.GDCatObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDDogObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDKnightObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDRobotObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDAdventureBoyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDNinjaBoyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDNinjaGirlObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDZombieBoyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDAdventureGirlObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Level1Code.GDZombieGirlObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level1Code.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.Level1Code.GDCatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects1);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDCatObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDCatObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDCatObjects1[k] = gdjs.Level1Code.GDCatObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDCatObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDogObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDDogObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDDogObjects1[k] = gdjs.Level1Code.GDDogObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDDogObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDKnightObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDKnightObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDKnightObjects1[k] = gdjs.Level1Code.GDKnightObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDKnightObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDRobotObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDRobotObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDRobotObjects1[k] = gdjs.Level1Code.GDRobotObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDRobotObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureBoyObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDAdventureBoyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureBoyObjects1[k] = gdjs.Level1Code.GDAdventureBoyObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureBoyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaBoyObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDNinjaBoyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaBoyObjects1[k] = gdjs.Level1Code.GDNinjaBoyObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaBoyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDNinjaGirlObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDNinjaGirlObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDNinjaGirlObjects1[k] = gdjs.Level1Code.GDNinjaGirlObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDNinjaGirlObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieBoyObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDZombieBoyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieBoyObjects1[k] = gdjs.Level1Code.GDZombieBoyObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieBoyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDAdventureGirlObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDAdventureGirlObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDAdventureGirlObjects1[k] = gdjs.Level1Code.GDAdventureGirlObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDAdventureGirlObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDZombieGirlObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDZombieGirlObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDZombieGirlObjects1[k] = gdjs.Level1Code.GDZombieGirlObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDZombieGirlObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17607860);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDAdventureBoyObjects1 */
/* Reuse gdjs.Level1Code.GDAdventureGirlObjects1 */
/* Reuse gdjs.Level1Code.GDCatObjects1 */
/* Reuse gdjs.Level1Code.GDDogObjects1 */
/* Reuse gdjs.Level1Code.GDKnightObjects1 */
/* Reuse gdjs.Level1Code.GDNinjaBoyObjects1 */
/* Reuse gdjs.Level1Code.GDNinjaGirlObjects1 */
/* Reuse gdjs.Level1Code.GDRobotObjects1 */
/* Reuse gdjs.Level1Code.GDZombieBoyObjects1 */
/* Reuse gdjs.Level1Code.GDZombieGirlObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDCatObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDCatObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDDogObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDKnightObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDRobotObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects1[i].getBehavior("Animation").setAnimationName("Dead");
}
}
{ //Subevents
gdjs.Level1Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.adMob.setupBanner("ca-app-pub-4492434867800612/4006657601", "", true);
}{runtimeScene.getGame().getVariables().get("Score").setNumber(0);
}{gdjs.adMob.showBanner();
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects1);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.Level1Code.GDAdventureBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.Level1Code.GDAdventureGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.Level1Code.GDDogObjects1);
gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.Level1Code.GDKnightObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.Level1Code.GDNinjaBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.Level1Code.GDNinjaGirlObjects1);
gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.Level1Code.GDRobotObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.Level1Code.GDZombieBoyObjects1);
gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.Level1Code.GDZombieGirlObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDDogObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDogObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDRobotObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDRobotObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDNinjaGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNinjaGirlObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDKnightObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDKnightObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieGirlObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDZombieBoyObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDZombieBoyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level1Code.GDAdventureGirlObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDAdventureGirlObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.Level1Code.eventsList0(runtimeScene);
}


{


gdjs.Level1Code.eventsList2(runtimeScene);
}


{


gdjs.Level1Code.eventsList3(runtimeScene);
}


{


gdjs.Level1Code.eventsList4(runtimeScene);
}


{


gdjs.Level1Code.eventsList7(runtimeScene);
}


{


gdjs.Level1Code.eventsList10(runtimeScene);
}


};

gdjs.Level1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1Code.GDScoreObjects1.length = 0;
gdjs.Level1Code.GDScoreObjects2.length = 0;
gdjs.Level1Code.GDScoreObjects3.length = 0;
gdjs.Level1Code.GDScoreObjects4.length = 0;
gdjs.Level1Code.GDScoreObjects5.length = 0;
gdjs.Level1Code.GDLifeObjects1.length = 0;
gdjs.Level1Code.GDLifeObjects2.length = 0;
gdjs.Level1Code.GDLifeObjects3.length = 0;
gdjs.Level1Code.GDLifeObjects4.length = 0;
gdjs.Level1Code.GDLifeObjects5.length = 0;
gdjs.Level1Code.GDShape2Objects1.length = 0;
gdjs.Level1Code.GDShape2Objects2.length = 0;
gdjs.Level1Code.GDShape2Objects3.length = 0;
gdjs.Level1Code.GDShape2Objects4.length = 0;
gdjs.Level1Code.GDShape2Objects5.length = 0;
gdjs.Level1Code.GDShape1Objects1.length = 0;
gdjs.Level1Code.GDShape1Objects2.length = 0;
gdjs.Level1Code.GDShape1Objects3.length = 0;
gdjs.Level1Code.GDShape1Objects4.length = 0;
gdjs.Level1Code.GDShape1Objects5.length = 0;
gdjs.Level1Code.GDShape3Objects1.length = 0;
gdjs.Level1Code.GDShape3Objects2.length = 0;
gdjs.Level1Code.GDShape3Objects3.length = 0;
gdjs.Level1Code.GDShape3Objects4.length = 0;
gdjs.Level1Code.GDShape3Objects5.length = 0;
gdjs.Level1Code.GDShape4Objects1.length = 0;
gdjs.Level1Code.GDShape4Objects2.length = 0;
gdjs.Level1Code.GDShape4Objects3.length = 0;
gdjs.Level1Code.GDShape4Objects4.length = 0;
gdjs.Level1Code.GDShape4Objects5.length = 0;
gdjs.Level1Code.GDShape1ExplosionObjects1.length = 0;
gdjs.Level1Code.GDShape1ExplosionObjects2.length = 0;
gdjs.Level1Code.GDShape1ExplosionObjects3.length = 0;
gdjs.Level1Code.GDShape1ExplosionObjects4.length = 0;
gdjs.Level1Code.GDShape1ExplosionObjects5.length = 0;
gdjs.Level1Code.GDShape2ExplosionObjects1.length = 0;
gdjs.Level1Code.GDShape2ExplosionObjects2.length = 0;
gdjs.Level1Code.GDShape2ExplosionObjects3.length = 0;
gdjs.Level1Code.GDShape2ExplosionObjects4.length = 0;
gdjs.Level1Code.GDShape2ExplosionObjects5.length = 0;
gdjs.Level1Code.GDShape3ExplosionObjects1.length = 0;
gdjs.Level1Code.GDShape3ExplosionObjects2.length = 0;
gdjs.Level1Code.GDShape3ExplosionObjects3.length = 0;
gdjs.Level1Code.GDShape3ExplosionObjects4.length = 0;
gdjs.Level1Code.GDShape3ExplosionObjects5.length = 0;
gdjs.Level1Code.GDShape4ExplosionObjects1.length = 0;
gdjs.Level1Code.GDShape4ExplosionObjects2.length = 0;
gdjs.Level1Code.GDShape4ExplosionObjects3.length = 0;
gdjs.Level1Code.GDShape4ExplosionObjects4.length = 0;
gdjs.Level1Code.GDShape4ExplosionObjects5.length = 0;
gdjs.Level1Code.GDObstacleObjects1.length = 0;
gdjs.Level1Code.GDObstacleObjects2.length = 0;
gdjs.Level1Code.GDObstacleObjects3.length = 0;
gdjs.Level1Code.GDObstacleObjects4.length = 0;
gdjs.Level1Code.GDObstacleObjects5.length = 0;
gdjs.Level1Code.GDCatObjects1.length = 0;
gdjs.Level1Code.GDCatObjects2.length = 0;
gdjs.Level1Code.GDCatObjects3.length = 0;
gdjs.Level1Code.GDCatObjects4.length = 0;
gdjs.Level1Code.GDCatObjects5.length = 0;
gdjs.Level1Code.GDDogObjects1.length = 0;
gdjs.Level1Code.GDDogObjects2.length = 0;
gdjs.Level1Code.GDDogObjects3.length = 0;
gdjs.Level1Code.GDDogObjects4.length = 0;
gdjs.Level1Code.GDDogObjects5.length = 0;
gdjs.Level1Code.GDRobotObjects1.length = 0;
gdjs.Level1Code.GDRobotObjects2.length = 0;
gdjs.Level1Code.GDRobotObjects3.length = 0;
gdjs.Level1Code.GDRobotObjects4.length = 0;
gdjs.Level1Code.GDRobotObjects5.length = 0;
gdjs.Level1Code.GDKnightObjects1.length = 0;
gdjs.Level1Code.GDKnightObjects2.length = 0;
gdjs.Level1Code.GDKnightObjects3.length = 0;
gdjs.Level1Code.GDKnightObjects4.length = 0;
gdjs.Level1Code.GDKnightObjects5.length = 0;
gdjs.Level1Code.GDAdventureGirlObjects1.length = 0;
gdjs.Level1Code.GDAdventureGirlObjects2.length = 0;
gdjs.Level1Code.GDAdventureGirlObjects3.length = 0;
gdjs.Level1Code.GDAdventureGirlObjects4.length = 0;
gdjs.Level1Code.GDAdventureGirlObjects5.length = 0;
gdjs.Level1Code.GDZombieBoyObjects1.length = 0;
gdjs.Level1Code.GDZombieBoyObjects2.length = 0;
gdjs.Level1Code.GDZombieBoyObjects3.length = 0;
gdjs.Level1Code.GDZombieBoyObjects4.length = 0;
gdjs.Level1Code.GDZombieBoyObjects5.length = 0;
gdjs.Level1Code.GDNinjaGirlObjects1.length = 0;
gdjs.Level1Code.GDNinjaGirlObjects2.length = 0;
gdjs.Level1Code.GDNinjaGirlObjects3.length = 0;
gdjs.Level1Code.GDNinjaGirlObjects4.length = 0;
gdjs.Level1Code.GDNinjaGirlObjects5.length = 0;
gdjs.Level1Code.GDNinjaBoyObjects1.length = 0;
gdjs.Level1Code.GDNinjaBoyObjects2.length = 0;
gdjs.Level1Code.GDNinjaBoyObjects3.length = 0;
gdjs.Level1Code.GDNinjaBoyObjects4.length = 0;
gdjs.Level1Code.GDNinjaBoyObjects5.length = 0;
gdjs.Level1Code.GDAdventureBoyObjects1.length = 0;
gdjs.Level1Code.GDAdventureBoyObjects2.length = 0;
gdjs.Level1Code.GDAdventureBoyObjects3.length = 0;
gdjs.Level1Code.GDAdventureBoyObjects4.length = 0;
gdjs.Level1Code.GDAdventureBoyObjects5.length = 0;
gdjs.Level1Code.GDZombieGirlObjects1.length = 0;
gdjs.Level1Code.GDZombieGirlObjects2.length = 0;
gdjs.Level1Code.GDZombieGirlObjects3.length = 0;
gdjs.Level1Code.GDZombieGirlObjects4.length = 0;
gdjs.Level1Code.GDZombieGirlObjects5.length = 0;

gdjs.Level1Code.eventsList11(runtimeScene);

return;

}

gdjs['Level1Code'] = gdjs.Level1Code;
