gdjs.SkinsCode = {};
gdjs.SkinsCode.GDNewTextObjects1= [];
gdjs.SkinsCode.GDNewTextObjects2= [];
gdjs.SkinsCode.GDBorderObjects1= [];
gdjs.SkinsCode.GDBorderObjects2= [];
gdjs.SkinsCode.GDSelectObjects1= [];
gdjs.SkinsCode.GDSelectObjects2= [];
gdjs.SkinsCode.GDShape2Objects1= [];
gdjs.SkinsCode.GDShape2Objects2= [];
gdjs.SkinsCode.GDShape1Objects1= [];
gdjs.SkinsCode.GDShape1Objects2= [];
gdjs.SkinsCode.GDShape3Objects1= [];
gdjs.SkinsCode.GDShape3Objects2= [];
gdjs.SkinsCode.GDShape4Objects1= [];
gdjs.SkinsCode.GDShape4Objects2= [];
gdjs.SkinsCode.GDShape1ExplosionObjects1= [];
gdjs.SkinsCode.GDShape1ExplosionObjects2= [];
gdjs.SkinsCode.GDShape2ExplosionObjects1= [];
gdjs.SkinsCode.GDShape2ExplosionObjects2= [];
gdjs.SkinsCode.GDShape3ExplosionObjects1= [];
gdjs.SkinsCode.GDShape3ExplosionObjects2= [];
gdjs.SkinsCode.GDShape4ExplosionObjects1= [];
gdjs.SkinsCode.GDShape4ExplosionObjects2= [];
gdjs.SkinsCode.GDObstacleObjects1= [];
gdjs.SkinsCode.GDObstacleObjects2= [];
gdjs.SkinsCode.GDCatObjects1= [];
gdjs.SkinsCode.GDCatObjects2= [];
gdjs.SkinsCode.GDDogObjects1= [];
gdjs.SkinsCode.GDDogObjects2= [];
gdjs.SkinsCode.GDRobotObjects1= [];
gdjs.SkinsCode.GDRobotObjects2= [];
gdjs.SkinsCode.GDKnightObjects1= [];
gdjs.SkinsCode.GDKnightObjects2= [];
gdjs.SkinsCode.GDAdventureGirlObjects1= [];
gdjs.SkinsCode.GDAdventureGirlObjects2= [];
gdjs.SkinsCode.GDZombieBoyObjects1= [];
gdjs.SkinsCode.GDZombieBoyObjects2= [];
gdjs.SkinsCode.GDNinjaGirlObjects1= [];
gdjs.SkinsCode.GDNinjaGirlObjects2= [];
gdjs.SkinsCode.GDNinjaBoyObjects1= [];
gdjs.SkinsCode.GDNinjaBoyObjects2= [];
gdjs.SkinsCode.GDAdventureBoyObjects1= [];
gdjs.SkinsCode.GDAdventureBoyObjects2= [];
gdjs.SkinsCode.GDZombieGirlObjects1= [];
gdjs.SkinsCode.GDZombieGirlObjects2= [];


gdjs.SkinsCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cat"), gdjs.SkinsCode.GDCatObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDCatObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDCatObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDCatObjects1[k] = gdjs.SkinsCode.GDCatObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDCatObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
/* Reuse gdjs.SkinsCode.GDCatObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDCatObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDCatObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDCatObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDCatObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.SkinsCode.GDDogObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDDogObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDDogObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDDogObjects1[k] = gdjs.SkinsCode.GDDogObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDDogObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
/* Reuse gdjs.SkinsCode.GDDogObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(2);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDDogObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDDogObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDDogObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDDogObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AdventureGirl"), gdjs.SkinsCode.GDAdventureGirlObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDAdventureGirlObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDAdventureGirlObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDAdventureGirlObjects1[k] = gdjs.SkinsCode.GDAdventureGirlObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDAdventureGirlObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SkinsCode.GDAdventureGirlObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDAdventureGirlObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDAdventureGirlObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDAdventureGirlObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDAdventureGirlObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AdventureBoy"), gdjs.SkinsCode.GDAdventureBoyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDAdventureBoyObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDAdventureBoyObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDAdventureBoyObjects1[k] = gdjs.SkinsCode.GDAdventureBoyObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDAdventureBoyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SkinsCode.GDAdventureBoyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(4);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDAdventureBoyObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDAdventureBoyObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDAdventureBoyObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDAdventureBoyObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NinjaGirl"), gdjs.SkinsCode.GDNinjaGirlObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDNinjaGirlObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDNinjaGirlObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDNinjaGirlObjects1[k] = gdjs.SkinsCode.GDNinjaGirlObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDNinjaGirlObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
/* Reuse gdjs.SkinsCode.GDNinjaGirlObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(5);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDNinjaGirlObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDNinjaGirlObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDNinjaGirlObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDNinjaGirlObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NinjaBoy"), gdjs.SkinsCode.GDNinjaBoyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDNinjaBoyObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDNinjaBoyObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDNinjaBoyObjects1[k] = gdjs.SkinsCode.GDNinjaBoyObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDNinjaBoyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
/* Reuse gdjs.SkinsCode.GDNinjaBoyObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(6);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDNinjaBoyObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDNinjaBoyObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDNinjaBoyObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDNinjaBoyObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ZombieGirl"), gdjs.SkinsCode.GDZombieGirlObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDZombieGirlObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDZombieGirlObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDZombieGirlObjects1[k] = gdjs.SkinsCode.GDZombieGirlObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDZombieGirlObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
/* Reuse gdjs.SkinsCode.GDZombieGirlObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(7);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDZombieGirlObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDZombieGirlObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDZombieGirlObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDZombieGirlObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ZombieBoy"), gdjs.SkinsCode.GDZombieBoyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDZombieBoyObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDZombieBoyObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDZombieBoyObjects1[k] = gdjs.SkinsCode.GDZombieBoyObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDZombieBoyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
/* Reuse gdjs.SkinsCode.GDZombieBoyObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(8);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDZombieBoyObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDZombieBoyObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDZombieBoyObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDZombieBoyObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Robot"), gdjs.SkinsCode.GDRobotObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDRobotObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDRobotObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDRobotObjects1[k] = gdjs.SkinsCode.GDRobotObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDRobotObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
/* Reuse gdjs.SkinsCode.GDRobotObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(9);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDRobotObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDRobotObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDRobotObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDRobotObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Knight"), gdjs.SkinsCode.GDKnightObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDKnightObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDKnightObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDKnightObjects1[k] = gdjs.SkinsCode.GDKnightObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDKnightObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.SkinsCode.GDBorderObjects1);
/* Reuse gdjs.SkinsCode.GDKnightObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(10);
}{for(var i = 0, len = gdjs.SkinsCode.GDBorderObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBorderObjects1[i].getBehavior("Tween").addObjectPositionTween2("tween", (( gdjs.SkinsCode.GDKnightObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDKnightObjects1[0].getPointX("")) - 10, (( gdjs.SkinsCode.GDKnightObjects1.length === 0 ) ? 0 :gdjs.SkinsCode.GDKnightObjects1[0].getPointY("")) - 10, "easeOutQuad", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Select"), gdjs.SkinsCode.GDSelectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SkinsCode.GDSelectObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDSelectObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SkinsCode.GDSelectObjects1[k] = gdjs.SkinsCode.GDSelectObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDSelectObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};

gdjs.SkinsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SkinsCode.GDNewTextObjects1.length = 0;
gdjs.SkinsCode.GDNewTextObjects2.length = 0;
gdjs.SkinsCode.GDBorderObjects1.length = 0;
gdjs.SkinsCode.GDBorderObjects2.length = 0;
gdjs.SkinsCode.GDSelectObjects1.length = 0;
gdjs.SkinsCode.GDSelectObjects2.length = 0;
gdjs.SkinsCode.GDShape2Objects1.length = 0;
gdjs.SkinsCode.GDShape2Objects2.length = 0;
gdjs.SkinsCode.GDShape1Objects1.length = 0;
gdjs.SkinsCode.GDShape1Objects2.length = 0;
gdjs.SkinsCode.GDShape3Objects1.length = 0;
gdjs.SkinsCode.GDShape3Objects2.length = 0;
gdjs.SkinsCode.GDShape4Objects1.length = 0;
gdjs.SkinsCode.GDShape4Objects2.length = 0;
gdjs.SkinsCode.GDShape1ExplosionObjects1.length = 0;
gdjs.SkinsCode.GDShape1ExplosionObjects2.length = 0;
gdjs.SkinsCode.GDShape2ExplosionObjects1.length = 0;
gdjs.SkinsCode.GDShape2ExplosionObjects2.length = 0;
gdjs.SkinsCode.GDShape3ExplosionObjects1.length = 0;
gdjs.SkinsCode.GDShape3ExplosionObjects2.length = 0;
gdjs.SkinsCode.GDShape4ExplosionObjects1.length = 0;
gdjs.SkinsCode.GDShape4ExplosionObjects2.length = 0;
gdjs.SkinsCode.GDObstacleObjects1.length = 0;
gdjs.SkinsCode.GDObstacleObjects2.length = 0;
gdjs.SkinsCode.GDCatObjects1.length = 0;
gdjs.SkinsCode.GDCatObjects2.length = 0;
gdjs.SkinsCode.GDDogObjects1.length = 0;
gdjs.SkinsCode.GDDogObjects2.length = 0;
gdjs.SkinsCode.GDRobotObjects1.length = 0;
gdjs.SkinsCode.GDRobotObjects2.length = 0;
gdjs.SkinsCode.GDKnightObjects1.length = 0;
gdjs.SkinsCode.GDKnightObjects2.length = 0;
gdjs.SkinsCode.GDAdventureGirlObjects1.length = 0;
gdjs.SkinsCode.GDAdventureGirlObjects2.length = 0;
gdjs.SkinsCode.GDZombieBoyObjects1.length = 0;
gdjs.SkinsCode.GDZombieBoyObjects2.length = 0;
gdjs.SkinsCode.GDNinjaGirlObjects1.length = 0;
gdjs.SkinsCode.GDNinjaGirlObjects2.length = 0;
gdjs.SkinsCode.GDNinjaBoyObjects1.length = 0;
gdjs.SkinsCode.GDNinjaBoyObjects2.length = 0;
gdjs.SkinsCode.GDAdventureBoyObjects1.length = 0;
gdjs.SkinsCode.GDAdventureBoyObjects2.length = 0;
gdjs.SkinsCode.GDZombieGirlObjects1.length = 0;
gdjs.SkinsCode.GDZombieGirlObjects2.length = 0;

gdjs.SkinsCode.eventsList0(runtimeScene);

return;

}

gdjs['SkinsCode'] = gdjs.SkinsCode;
