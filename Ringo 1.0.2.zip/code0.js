gdjs.MainMenuCode = {};
gdjs.MainMenuCode.GDStartButtonObjects1= [];
gdjs.MainMenuCode.GDStartButtonObjects2= [];
gdjs.MainMenuCode.GDGameTitleObjects1= [];
gdjs.MainMenuCode.GDGameTitleObjects2= [];
gdjs.MainMenuCode.GDSkins2Objects1= [];
gdjs.MainMenuCode.GDSkins2Objects2= [];
gdjs.MainMenuCode.GDShape2Objects1= [];
gdjs.MainMenuCode.GDShape2Objects2= [];
gdjs.MainMenuCode.GDShape1Objects1= [];
gdjs.MainMenuCode.GDShape1Objects2= [];
gdjs.MainMenuCode.GDShape3Objects1= [];
gdjs.MainMenuCode.GDShape3Objects2= [];
gdjs.MainMenuCode.GDShape4Objects1= [];
gdjs.MainMenuCode.GDShape4Objects2= [];
gdjs.MainMenuCode.GDShape1ExplosionObjects1= [];
gdjs.MainMenuCode.GDShape1ExplosionObjects2= [];
gdjs.MainMenuCode.GDShape2ExplosionObjects1= [];
gdjs.MainMenuCode.GDShape2ExplosionObjects2= [];
gdjs.MainMenuCode.GDShape3ExplosionObjects1= [];
gdjs.MainMenuCode.GDShape3ExplosionObjects2= [];
gdjs.MainMenuCode.GDShape4ExplosionObjects1= [];
gdjs.MainMenuCode.GDShape4ExplosionObjects2= [];
gdjs.MainMenuCode.GDObstacleObjects1= [];
gdjs.MainMenuCode.GDObstacleObjects2= [];
gdjs.MainMenuCode.GDCatObjects1= [];
gdjs.MainMenuCode.GDCatObjects2= [];
gdjs.MainMenuCode.GDDogObjects1= [];
gdjs.MainMenuCode.GDDogObjects2= [];
gdjs.MainMenuCode.GDRobotObjects1= [];
gdjs.MainMenuCode.GDRobotObjects2= [];
gdjs.MainMenuCode.GDKnightObjects1= [];
gdjs.MainMenuCode.GDKnightObjects2= [];
gdjs.MainMenuCode.GDAdventureGirlObjects1= [];
gdjs.MainMenuCode.GDAdventureGirlObjects2= [];
gdjs.MainMenuCode.GDZombieBoyObjects1= [];
gdjs.MainMenuCode.GDZombieBoyObjects2= [];
gdjs.MainMenuCode.GDNinjaGirlObjects1= [];
gdjs.MainMenuCode.GDNinjaGirlObjects2= [];
gdjs.MainMenuCode.GDNinjaBoyObjects1= [];
gdjs.MainMenuCode.GDNinjaBoyObjects2= [];
gdjs.MainMenuCode.GDAdventureBoyObjects1= [];
gdjs.MainMenuCode.GDAdventureBoyObjects2= [];
gdjs.MainMenuCode.GDZombieGirlObjects1= [];
gdjs.MainMenuCode.GDZombieGirlObjects2= [];


gdjs.MainMenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.MainMenuCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDStartButtonObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDStartButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDStartButtonObjects1[k] = gdjs.MainMenuCode.GDStartButtonObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDStartButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.adMob.loadAppOpen("ca-app-pub-4492434867800612/4689167975", "", false, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Skins2"), gdjs.MainMenuCode.GDSkins2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainMenuCode.GDSkins2Objects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDSkins2Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainMenuCode.GDSkins2Objects1[k] = gdjs.MainMenuCode.GDSkins2Objects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDSkins2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Skins", true);
}}

}


};

gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainMenuCode.GDStartButtonObjects1.length = 0;
gdjs.MainMenuCode.GDStartButtonObjects2.length = 0;
gdjs.MainMenuCode.GDGameTitleObjects1.length = 0;
gdjs.MainMenuCode.GDGameTitleObjects2.length = 0;
gdjs.MainMenuCode.GDSkins2Objects1.length = 0;
gdjs.MainMenuCode.GDSkins2Objects2.length = 0;
gdjs.MainMenuCode.GDShape2Objects1.length = 0;
gdjs.MainMenuCode.GDShape2Objects2.length = 0;
gdjs.MainMenuCode.GDShape1Objects1.length = 0;
gdjs.MainMenuCode.GDShape1Objects2.length = 0;
gdjs.MainMenuCode.GDShape3Objects1.length = 0;
gdjs.MainMenuCode.GDShape3Objects2.length = 0;
gdjs.MainMenuCode.GDShape4Objects1.length = 0;
gdjs.MainMenuCode.GDShape4Objects2.length = 0;
gdjs.MainMenuCode.GDShape1ExplosionObjects1.length = 0;
gdjs.MainMenuCode.GDShape1ExplosionObjects2.length = 0;
gdjs.MainMenuCode.GDShape2ExplosionObjects1.length = 0;
gdjs.MainMenuCode.GDShape2ExplosionObjects2.length = 0;
gdjs.MainMenuCode.GDShape3ExplosionObjects1.length = 0;
gdjs.MainMenuCode.GDShape3ExplosionObjects2.length = 0;
gdjs.MainMenuCode.GDShape4ExplosionObjects1.length = 0;
gdjs.MainMenuCode.GDShape4ExplosionObjects2.length = 0;
gdjs.MainMenuCode.GDObstacleObjects1.length = 0;
gdjs.MainMenuCode.GDObstacleObjects2.length = 0;
gdjs.MainMenuCode.GDCatObjects1.length = 0;
gdjs.MainMenuCode.GDCatObjects2.length = 0;
gdjs.MainMenuCode.GDDogObjects1.length = 0;
gdjs.MainMenuCode.GDDogObjects2.length = 0;
gdjs.MainMenuCode.GDRobotObjects1.length = 0;
gdjs.MainMenuCode.GDRobotObjects2.length = 0;
gdjs.MainMenuCode.GDKnightObjects1.length = 0;
gdjs.MainMenuCode.GDKnightObjects2.length = 0;
gdjs.MainMenuCode.GDAdventureGirlObjects1.length = 0;
gdjs.MainMenuCode.GDAdventureGirlObjects2.length = 0;
gdjs.MainMenuCode.GDZombieBoyObjects1.length = 0;
gdjs.MainMenuCode.GDZombieBoyObjects2.length = 0;
gdjs.MainMenuCode.GDNinjaGirlObjects1.length = 0;
gdjs.MainMenuCode.GDNinjaGirlObjects2.length = 0;
gdjs.MainMenuCode.GDNinjaBoyObjects1.length = 0;
gdjs.MainMenuCode.GDNinjaBoyObjects2.length = 0;
gdjs.MainMenuCode.GDAdventureBoyObjects1.length = 0;
gdjs.MainMenuCode.GDAdventureBoyObjects2.length = 0;
gdjs.MainMenuCode.GDZombieGirlObjects1.length = 0;
gdjs.MainMenuCode.GDZombieGirlObjects2.length = 0;

gdjs.MainMenuCode.eventsList0(runtimeScene);

return;

}

gdjs['MainMenuCode'] = gdjs.MainMenuCode;
